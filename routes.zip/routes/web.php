<?php

use App\Http\Controllers\Homecontroller;
use App\Http\Controllers\BackendController;
use App\Http\Controllers\AdminController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Route::get('/',[Homecontroller::class,'index']);
Route::get('/about',[Homecontroller::class,'about']);
Route::get('/',[Homecontroller::class,'homepage']);
Route::get('/contact',[Homecontroller::class,'contact']);
Route::get('/services',[Homecontroller::class,'services']);

Route::get('/signup',[BackendController::class,'signup'])->name('signup');
Route::post('/signupData',[BackendController::class,'signupData']);

Route::get('/login',[BackendController::class,'login'])->name('login');
Route::get('/admin',[BackendController::class,'admin'])->name('admin');
Route::post('/logincheck',[BackendController::class,'logincheck'])->name('logincheck');


Route::get('/addnewplace',[AdminController::class,'addnewplace'])->name('addnewplace');
Route::get('/service',[AdminController::class,'service'])->name('service');
Route::get('/visitortable',[AdminController::class,'visitortable'])->name('visitortable');


Route::post('/message-insert',[Homecontroller::class,'messageInsert'])->name('message.insert');




