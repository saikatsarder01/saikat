<?php $__env->startSection('title'); ?>
    <?php echo e('Services'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('service'); ?>
    <section class="section section-sm section-first bg-default fadeInUp wow pt-5">
        <div class="container">
            <h2>
                Our Services
            </h2>
        </div>
        <div class="container">
            <div class="row row-30 justify-content-center">
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s1.png" class="img1" alt="">
                            </div>
                            
                            <p class="box-contacts-link my-2">Single Tour Packages</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s2.png" class="img1" alt="">
                            </div>
                            
                            <p class="box-contacts-link my-2">Group Tour Packages</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s3.png" class="img1" alt="">
                            </div>
                            
                            <p class="box-contacts-link my-2">Travel Insurance</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s4.png" class="img1" alt="">
                            </div>
                            
                            <p class="box-contacts-link my-2">Travel Consulting</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s5.png" class="img1" alt="">
                            </div>
                            
                            <p class="box-contacts-link my-2">Flight & Hotel Booking</p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\OneDrive\Desktop\travel\travel\resources\views/Frontend/services.blade.php ENDPATH**/ ?>