
<?php $__env->startSection('contactpage'); ?>
    

<iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d459.6873221019771!2d89.5422096!3d22.8210365!3m2!1i1024!2i768!4f13.1!2m1!1ssonadanga%202nd%20phase%20road%2014!5e0!3m2!1sen!2sbd!4v1702787096982!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

  <!-- Contact information-->
  <section class="section section-sm section-first bg-default">
    <div class="container">
      <div class="row row-30 justify-content-center">
        <div class="col-sm-8 col-md-6 col-lg-4">
          <article class="box-contacts">
            <div class="box-contacts-body">
              <div class="box-contacts-icon fl-bigmug-line-cellphone55"></div>
              <div class="box-contacts-decor"></div>
              <p class="box-contacts-link"><a href="tel:#">+880 1794220754</a></p>
              <p class="box-contacts-link"><a href="tel:#">+880 1641458356</a></p>
            </div>
          </article>
        </div>
        <div class="col-sm-8 col-md-6 col-lg-4">
          <article class="box-contacts">
            <div class="box-contacts-body">
              <div class="box-contacts-icon fl-bigmug-line-up104"></div>
              <div class="box-contacts-decor"></div>
              <p class="box-contacts-link"><a href="#">247/14 Sonadanga Abasik 2nd Phase, Sonadaga Khulna</a></p>
            </div>
          </article>
        </div>
        <div class="col-sm-8 col-md-6 col-lg-4">
          <article class="box-contacts">
            <div class="box-contacts-body">
              <div class="box-contacts-icon fl-bigmug-line-chat55"></div>
              <div class="box-contacts-decor"></div>
              <p class="box-contacts-link"><a href="mailto:#">saikatsarder01@gmail.com</a></p>
            </div>
          </article>
        </div>
      </div>
    </div>
  </section>


    </div>
  </section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Downloads\Programs\travel\travel\resources\views/Frontend/contact.blade.php ENDPATH**/ ?>