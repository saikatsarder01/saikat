 <!-- Javascript-->
 <script src="<?php echo e(asset('frontend/js/core.min.js')); ?>"></script>
 <script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script><?php /**PATH C:\Users\user\Desktop\travel\resources\views/Frontend/component/js.blade.php ENDPATH**/ ?>