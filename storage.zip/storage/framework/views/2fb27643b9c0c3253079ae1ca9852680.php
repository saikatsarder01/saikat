<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
    <?php echo $__env->make('Frontend.component.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>
        <?php if (! empty(trim($__env->yieldContent('title')))): ?>
            <?php echo $__env->yieldContent('title'); ?> - Wonder Tour
        <?php else: ?>
            Wonder Tour
        <?php endif; ?>
    </title>
</head>

<body>

    <?php echo $__env->make('Frontend.component.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('homepage'); ?>
    <?php echo $__env->yieldContent('about'); ?>
    <?php echo $__env->yieldContent('contactpage'); ?>
    <?php echo $__env->yieldContent('service'); ?>
    <?php echo $__env->make('Frontend.component.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="snackbars" id="form-output-global"></div>
    <?php echo $__env->make('Frontend.component.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\USER\OneDrive\Desktop\travel\travel\resources\views/Frontend/master.blade.php ENDPATH**/ ?>