
<div class="modal fade" id="addCourseModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title">Add New Place</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body  text-center">
       <div class="container">
       	<div class="row">
       		<div class="col-md-6">
             	<input id="CourseNameId" type="text" id="" class="form-control mb-3" placeholder="Place Name">
          	 	<input id="CourseDesId" type="text" id="" class="form-control mb-3" placeholder="Place Description">
    		 	<input id="CourseFeeId" type="text" id="" class="form-control mb-3" placeholder="Tour Cost">
     			<input id="CourseEnrollId" type="text" id="" class="form-control mb-3" placeholder="Number of Participate">
       		</div>
       		<div class="col-md-6">
     			<input id="CourseClassId" type="text" id="" class="form-control mb-3" placeholder="Tour Length">      
     			<input id="CourseImgId" type="text" id="" class="form-control mb-3" placeholder="Place Image">
       		</div>
       	</div>
       </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal" href="admin" >Cancel</button>
        <button  id="CourseAddConfirmBtn" type="button" class="btn  btn-sm  btn-danger" href="admin">Save</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH F:\Travel agency Practice Project\travel\resources\views/Backend/addnewplace.blade.php ENDPATH**/ ?>