 <!-- Javascript-->
 <script src="<?php echo e(asset('frontend/js/core.min.js')); ?>"></script>
 <script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script><?php /**PATH F:\530.hridoy\travel\resources\views/Frontend/component/js.blade.php ENDPATH**/ ?>