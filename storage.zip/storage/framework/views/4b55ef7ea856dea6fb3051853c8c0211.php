<?php $__env->startSection('contactpage'); ?>
    <!-- contact section -->

    <section class="section section-sm section-first fadeInUp wow pt-5">
        <div class="container" >
            <h2>
                Contact Us
            </h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-2 mb-lg-0 fadeInRight" data-wow-delay=".1s">
                    <form action="" class="p-4 bg-light shadow">
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Name" required />
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Email" required />
                        </div>
                        <div class="mb-3">
                            <input type="tel" class="form-control" placeholder="Phone Number" pattern="[0-9]{10}"
                                title="Enter a 10-digit phone number" required />
                        </div>
                        <div class="mb-4">
                            <textarea class="form-control" placeholder="Message" rows="5" required></textarea>
                        </div>
                        <div class="group-md group-middle">
                            <button type="submit" class="button button-width-xl-230 button-primary button-pipaluk">
                                SEND
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-lg-6 fadeInLeft" data-wow-delay=".1s">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d459.6873221019771!2d89.5422096!3d22.8210365!3m2!1i1024!2i768!4f13.1!2m1!1ssonadanga%202nd%20phase%20road%2014!5e0!3m2!1sen!2sbd!4v1702787096982!5m2!1sen!2sbd"
                        width="100%" height="420px" style="border:0;" allowfullscreen="" loading="lazy" class="bg-light"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
        </div>
    </section>

    

    <section class="section section-sm section-first bg-default">
        <div class="container">
            <div class="row row-30 justify-content-center">
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="box-contacts-icon fl-bigmug-line-cellphone55"></div>
                            <div class="box-contacts-decor"></div>
                            <p class="box-contacts-link"><a href="tel:#">+880 1794220754</a></p>
                            <p class="box-contacts-link"><a href="tel:#">+880 1641458356</a></p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="box-contacts-icon fl-bigmug-line-up104"></div>
                            <div class="box-contacts-decor"></div>
                            <p class="box-contacts-link"><a href="#">247/14 Sonadanga Abasik 2nd Phase, Sonadaga
                                    Khulna</a></p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="box-contacts-icon fl-bigmug-line-chat55"></div>
                            <div class="box-contacts-decor"></div>
                            <p class="box-contacts-link"><a href="mailto:#">saikatsarder01@gmail.com</a></p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Work\hridoy\travel\resources\views/Frontend/contact.blade.php ENDPATH**/ ?>