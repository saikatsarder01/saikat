<div class="page">

    <header class="section page-header">
        <!-- RD Navbar-->
        <div class="rd-navbar-wrap">
            <nav class="rd-navbar rd-navbar-corporate" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed"
                data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static"
                data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static"
                data-xl-device-layout="rd-navbar-static" data-xxl-layout="rd-navbar-static"
                data-xxl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px"
                data-xxl-stick-up-offset="106px" data-lg-stick-up="true" data-xl-stick-up="true"
                data-xxl-stick-up="true">
                <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1"
                    data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
                <div class="rd-navbar-aside-outer">
                    <div class="rd-navbar-aside">
                        <!-- RD Navbar Panel-->
                        <div class="rd-navbar-panel">
                            <!-- RD Navbar Toggle-->
                            <button class="rd-navbar-toggle"
                                data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                            <!-- RD Navbar Brand-->
                            <div class="rd-navbar-brand">
                                <!--Brand--><a class="brand" href="/"><img
                                        src="frontend/images/logo-default-450x37.png" alt="" width="225"
                                        height="18" /></a>
                            </div>
                        </div>
                        <div class="rd-navbar-aside-right rd-navbar-collapse">
                            <ul class="rd-navbar-corporate-contacts">
                                <li>
                                    <div class="unit unit-spacing-xs">
                                        <div class="unit-left"><span class="icon fa fa-clock-o"></span></div>
                                        <div class="unit-body">
                                            <p>09:00<span>am</span> — 05:00<span>pm</span></p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="unit unit-spacing-xs">
                                        <div class="unit-left"><span class="icon fa fa-phone"></span></div>
                                        <div class="unit-body"><a class="link-phone" href="tel:#">+8801794220754</a>
                                        </div>
                                    </div>
                                </li>
                            </ul><a class="button button-md button-default-outline-2 button-ujarak"
                                href="signup">SignUp Here</a>
                        </div>
                    </div>
                </div>
                <div class="rd-navbar-main-outer">
                    <div class="rd-navbar-main">
                        <div class="rd-navbar-nav-wrap">
                            <ul class="list-inline list-inline-md rd-navbar-corporate-list-social">
                                <li><a class="icon fa fa-facebook" href="#"></a></li>
                                <li><a class="icon fa fa-twitter" href="#"></a></li>
                                <li><a class="icon fa fa-google-plus" href="#"></a></li>
                                <li><a class="icon fa fa-instagram" href="#"></a></li>
                            </ul>
                            <!-- RD Navbar Nav-->
                            <ul class="rd-navbar-nav">
                                <li class="rd-nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                                    <a class="rd-nav-link" href="/">Home</a>
                                </li>
                                <li class="rd-nav-item <?php echo e(Request::is('services') ? 'active' : ''); ?>">
                                    <a class="rd-nav-link" href="services">Services</a>
                                </li>
                                <li class="rd-nav-item <?php echo e(Request::is('about') ? 'active' : ''); ?>">
                                    <a class="rd-nav-link" href="about">About</a>
                                </li>
                                <li class="rd-nav-item <?php echo e(Request::is('contact') ? 'active' : ''); ?>">
                                    <a class="rd-nav-link" href="contact">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- Swiper-->

    <section <?php echo e(!Request::is('/') ? 'style=display:none' : ''); ?> class="section swiper-container swiper-slider swiper-slider-corporate swiper-pagination-style-2"
        data-loop="true" data-autoplay="5000" data-simulate-touch="true" data-nav="false" data-direction="vertical">
        <div class="swiper-wrapper text-left">
            <div class="swiper-slide context-dark" data-slide-bg="images/slider-4-slide-1-1920x678.jpg">
                <div class="swiper-slide-caption section-md">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10">
                                <h6 class="text-uppercase" data-caption-animate="fadeInRight" data-caption-delay="0">
                                    Enjoy the Best Destinations with Our Travel Agency</h6>
                                <h2 class="oh font-weight-light" data-caption-animate="slideInUp"
                                    data-caption-delay="100"><span>Explore</span><span class="font-weight-bold"> The
                                        World</span></h2><a class="button button-default-outline button-ujarak"
                                    href="contact" data-caption-animate="fadeInLeft" data-caption-delay="0">Get in
                                    touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide context-dark" data-slide-bg="images/slider-4-slide-2-1920x678.jpg">
                <div class="swiper-slide-caption section-md">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10">
                                <h6 class="text-uppercase" data-caption-animate="fadeInRight" data-caption-delay="0">
                                    A team of professional Travel Experts</h6>
                                <h2 class="oh font-weight-light" data-caption-animate="slideInUp"
                                    data-caption-delay="100"><span>Trust</span><span class="font-weight-bold"> Our
                                        Experience</span></h2><a class="button button-default-outline button-ujarak"
                                    href="#" data-caption-animate="fadeInLeft" data-caption-delay="0">Get in
                                    touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide context-dark" data-slide-bg="images/slider-4-slide-3-1920x678.jpg">
                <div class="swiper-slide-caption section-md">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10">
                                <h6 class="text-uppercase" data-caption-animate="fadeInRight" data-caption-delay="0">
                                    Build your Next Holiday Trip with Us</h6>
                                <h2 class="oh font-weight-light" data-caption-animate="slideInUp"
                                    data-caption-delay="100"><span>Create</span><span class="font-weight-bold"> Your
                                        Tour</span></h2><a class="button button-default-outline button-ujarak"
                                    href="#" data-caption-animate="fadeInLeft" data-caption-delay="0">Get in
                                    touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Swiper Pagination-->
        <div class="swiper-pagination"></div>
    </section>
<?php /**PATH C:\Users\USER\Downloads\travel\travel\resources\views/Frontend/component/header.blade.php ENDPATH**/ ?>