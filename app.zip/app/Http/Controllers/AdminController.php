<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function addnewplace(){
        return view ('Backend.addnewplace');
    }

    public function service(){
        return view ('Backend.service');
    }

    public function visitortable(){
        return view ('Backend.visitortable');
    }
}
