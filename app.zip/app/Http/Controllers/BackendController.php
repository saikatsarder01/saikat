<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class BackendController extends Controller
{
    public function signup(){
        return view ('Backend.signup');
    }

    public function signupData(REQUEST $request){
        $data['name']=$request->name;
        $data['email']=$request ->email;
        $data['phone']=$request ->phone;
        $data['password']= Hash::make($request ->password);

        User::insert($data);
        return redirect('login');

    }

    public function login(){
        return view ('Backend.login');
    }

    public function admin(){
        return view ('Backend.master');
    }

    public function logincheck(Request $data){
        //dd($data->all());

        if(Auth::attempt(['email' => $data->email, 'password' => $data-> password])){

            return redirect()->route('admin');
         } else{
                return redirect()->route('login');
            }
        }

       
    }
