<?php

namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;

class Homecontroller extends Controller
{
    public function index(){
        return view ('Frontend.master');
    }

    public function about(){
        return view ('Frontend.about');
    }

    public function homepage(){
        return view ('Frontend.component.homepage');
    }

    public function services(){
        return view ('Frontend.services');
    }

    public function contact(){
        return view ('Frontend.contact');
    }

    public function messageInsert(Request $request){
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'message' => 'required|string',
            'phone' => 'required|string|regex:/^[0-9]{11}$/',
        ]);

        Message::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'phone' => $request->input('phone'),
            'message' => $request->input('message'),
        ]);

        return redirect()->back()->with('status', 'Thank you for reaching out! We will get back to you soon.');
        }

}
