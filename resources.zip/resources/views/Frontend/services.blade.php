@extends('Frontend.master')
@section('title')
    {{ 'Services' }}
@endsection
@section('service')
    <section class="section section-sm section-first bg-default fadeInUp wow pt-5">
        <div class="container">
            <h2>
                Our Services
            </h2>
        </div>
        <div class="container">
            <div class="row row-30 justify-content-center">
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s1.png" class="img1" alt="">
                            </div>
                            {{-- <div class="box-contacts-decor"></div> --}}
                            <p class="box-contacts-link my-2">Single Tour Packages</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s2.png" class="img1" alt="">
                            </div>
                            {{-- <div class="box-contacts-decor"></div> --}}
                            <p class="box-contacts-link my-2">Group Tour Packages</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s3.png" class="img1" alt="">
                            </div>
                            {{-- <div class="box-contacts-decor"></div> --}}
                            <p class="box-contacts-link my-2">Travel Insurance</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s4.png" class="img1" alt="">
                            </div>
                            {{-- <div class="box-contacts-decor"></div> --}}
                            <p class="box-contacts-link my-2">Travel Consulting</p>
                        </div>
                    </article>
                </div>
                <div class="col-sm-8 col-md-6 col-lg-4">
                    <article class="box-contacts">
                        <div class="box-contacts-body">
                            <div class="img-box mt-3">
                                <img src="images/s5.png" class="img1" alt="">
                            </div>
                            {{-- <div class="box-contacts-decor"></div> --}}
                            <p class="box-contacts-link my-2">Flight & Hotel Booking</p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>

    {{--<!-- service section -->
    <section class="service_section layout_padding">
        <div class="container">
            <div class="service_container">
                <div class="box">
                    <div class="img-box mt-3">
                        <img src="images/s1.png" class="img1" alt="">
                    </div>
                    <div class="detail-box">
                        <h5>
                            Single Tour Packages
                        </h5>
                        <p>
                            “Remember that happiness is a way of travel – not a destination.” – Roy M. Goodman
                        </p>
                    </div>
                </div>
                <div class="box active">
                    <div class="img-box">
                        <img src="images/s2.png" class="img1" alt="">
                    </div>
                    <div class="detail-box">
                        <h5>
                            Group Tour Packages
                        </h5>
                        <p>
                            “Remember that happiness is a way of travel – not a destination.” – Roy M. Goodman
                        </p>
                    </div>
                </div>
                <div class="box">
                    <div class="img-box">
                        <img src="images/s3.png" class="img1" alt="">
                    </div>
                    <div class="detail-box">
                        <h5>
                            Travel Insurance
                        </h5>
                        <p>
                            “Remember that happiness is a way of travel – not a destination.” – Roy M. Goodman
                        </p>
                    </div>
                </div>
                <div class="box ">
                    <div class="img-box">
                        <img src="images/s4.png" class="img1" alt="">
                    </div>
                    <div class="detail-box">
                        <h5>
                            Travel Consulting
                        </h5>
                        <p>
                            “Remember that happiness is a way of travel – not a destination.” – Roy M. Goodman
                        </p>
                    </div>
                </div>
                <div class="box">
                    <div class="img-box">
                        <img src="images/s5.png" class="img1" alt="">
                    </div>
                    <div class="detail-box">
                        <h5>
                            Flight & Hotel Booking
                        </h5>
                        <p>
                            “Remember that happiness is a way of travel – not a destination.” – Roy M. Goodman
                        </p>
                    </div>
                </div>
            </div>
            <div class="btn-box">
                <a href="contact">
                    Read More
                </a>
            </div>
        </div>
    </section>
    <!-- end service section -->
    <!-- about section -->
    <section class="about_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="detail-box">
                        <div class="heading_container">
                            <h2>
                                About Us
                            </h2>
                        </div>
                        <p>
                            “The more I traveled the more I realized that fear makes strangers of people who should be
                            friends.” – Shirley MacLaine “Travel makes one modest. You see what a tiny place you occupy
                            in the world.” – Gustave Flaubert “You don’t have to be rich to travel well.” – Eugene Fodor
                        </p>
                        <a href="about">
                            Read More
                        </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="img_container">
                        <div class="img-box b1">
                            <img src="images/about-img1.jpg" alt="" />
                        </div>
                        <div class="img-box b2">
                            <img src="images/about-img2.jpg" alt="" />
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </section>
    <!-- end about section -->
    <!-- info section -->
    <section class="info_section layout_padding">
        <div class="container">
            <div class="info_contact">
                <div class="row">
                    <div class="col-md-4">
                        <a href="">
                            <img src="images/location-white.png" alt="">
                            <span>
                                Sonadanga 2nd Phase, Sonadanga Abasik, Khulna
                            </span>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="">
                            <img src="images/telephone-white.png" alt="">
                            <span>
                                Call : +8801906590050
                            </span>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="">
                            <img src="images/envelope-white.png" alt="">
                            <span>
                                nafiulraj007@gmail.com
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-lg-9">
                    <div class="info_form">
                        <form action="">
                            <input type="text" placeholder="Enter your email">
                            <button>
                                subscribe
                            </button>
                        </form>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="info_social">
                        <div>
                            <a href="">
                                <img src="images/fb.png" alt="">
                            </a>
                        </div>
                        <div>
                            <a href="">
                                <img src="images/twitter.png" alt="">
                            </a>
                        </div>
                        <div>
                            <a href="">
                                <img src="images/linkedin.png" alt="">
                            </a>
                        </div>
                        <div>
                            <a href="">
                                <img src="images/instagram.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section> --}}
@endsection
