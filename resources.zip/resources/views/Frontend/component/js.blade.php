 <!-- Javascript-->
 <script src="{{ asset('frontend/js/core.min.js')}}"></script>
 <script src="{{ asset('frontend/js/script.js')}}"></script>