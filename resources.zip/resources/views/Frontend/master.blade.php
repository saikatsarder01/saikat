<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
    @include('Frontend.component.css')
    <title>
        @hasSection('title')
            @yield('title') - Wonder Tour
        @else
            Wonder Tour
        @endif
    </title>
</head>

<body>

    @include('Frontend.component.header')

    @yield('homepage')
    @yield('about')
    @yield('contactpage')
    @yield('service')
    @include('Frontend.component.footer')
    <div class="snackbars" id="form-output-global"></div>
    @include('Frontend.component.js')
</body>

</html>
